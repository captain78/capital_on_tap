#install choco
Set-ExecutionPolicy Bypass -Scope Process -Force; [System.Net.ServicePointManager]::SecurityProtocol = [System.Net.ServicePointManager]::SecurityProtocol -bor 3072; iex ((New-Object System.Net.WebClient).DownloadString('https://chocolatey.org/install.ps1'))
#Choco install packages
choco install dotnetcore --version=2.2.6
choco install dotnet4.7.2
choco install dotnetcore-windowshosting --version=2.2.0